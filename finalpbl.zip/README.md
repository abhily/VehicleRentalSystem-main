# VehicleRentalSystem
## A C++ based Vehicle Rental System


> Application Architecture

![Alt text](AppArch.png)
---
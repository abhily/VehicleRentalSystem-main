#include<iostream>
#include<stdlib.h>
#include<fstream>
using namespace std;

void admin_menu();

int add_vehicle();
void new_admin();

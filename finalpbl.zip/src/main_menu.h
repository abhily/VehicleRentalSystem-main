#include <iostream>
#include<stdlib.h>
#include<fstream>
using namespace std;

int main_menu();
void  authentication();
bool auth_check(const string &username, const string &pass);
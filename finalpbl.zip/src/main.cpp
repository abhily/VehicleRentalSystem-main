#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<fstream>
#include"admin.h"
#include"admin.cpp"
#include"user_menu.h"
#include"user_menu.cpp"
#include"main_menu.h"
#include"main_menu.cpp"
#include"new_user.h"
#include"new_user.cpp"
#include"existing_user.h"
#include"existing_user.cpp"
using namespace std;

int main()
{
    main_menu();
    return 0;
}


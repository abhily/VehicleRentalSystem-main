#include <iostream>
#include<stdlib.h>
#include<fstream>

int new_user();